`pragma protect begin_protected
`pragma protect version="1.0"
`pragma protect author="default"
`pragma protect author_info="default"
`pragma protect encrypt_agent="GOWIN"
`pragma protect encrypt_agent_info="GOWIN Encrypt Version 1.0"

`pragma protect encoding=(enctype="base64", line_length=76, bytes=256)
`pragma protect key_keyowner="GOWIN",key_keyname="GWK2022-11",key_method="rsa"
`pragma protect key_block
ZZ4ShSMOmlpbGDV4xkfp3L1ACgNPDhtUJ89q9K0Gf4b+NDlDkzm/VQ/Jb/EXaIAPz7HQQFXmfc0+
rD2FsOLYEj7STt/1hwNKiOK6IkSg3DlTJHoCPpW8oCOustgTfJFP301506dkbElA0y30G7iDKCc2
shiCYokUWWHrNU9alDID0jh0mV8FCuTYVuCs00shlGBPUaIF9lDt3qsZbHb2mvYYdYKhBDsANbT3
1nPZr+GC1+CtdTydCBjY2WHtZgObx35EH04zBr8UBxJV6+22xdxN6JWYdEDEFjvPE1L3AIYKn4iV
VtO3GAzMCFvQWTRgLlRiJ361f5aZjhmtcm5OrQ==

`pragma protect encoding=(enctype="base64", line_length=76, bytes=256)
`pragma protect data_keyowner="default-ip-vendor"
`pragma protect data_keyname="default-ip-key"
`pragma protect data_method="aes128-cbc"
`pragma protect data_block
lJqokVCTdT1RvbCn/Tr8ueMSyy7igLjKClvrcRZYHtTySEXRisn19579hOukiyv3CD2dNwDxD2Fv
ggpLuXSUkJVfPguin7GgqiYn5+kddNVdyFiG4qNzZfTd0ZnJYOLc6mAoU/9oNhV8UC9Ssq8hfE50
v+O5R1AhqUUkkTfa2ysj19CpBbqGLat0/WVNbP98DokSwpWoETs5wAdYIsx7e10hAjQYFV8wRYPy
/5mmCcICPSa5h/w+h6AkbObhe8jEBGd5osJ3+e7zyZCVgvHNcrVR7Wuo6owftF6JYk3bKYmm42Ei
8oPp7XvXfhzftO7HiRtmOl9vcwWkjgKxOcxh4w==
`pragma protect end_protected
